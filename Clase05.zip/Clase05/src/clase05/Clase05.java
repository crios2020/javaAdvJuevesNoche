package clase05;
public class Clase05 {
    private static String $;
    private static int _2;
    public static void main(String[] args) {
        // Clase 05 
        
        String texto=null;
        int nro=0;
        Integer nro2=null;
        
        System.out.println($);          // null
        System.out.println(_2);         // 0
        
        System.out.println(texto);
        System.out.println(nro);
        System.out.println(nro2);
        
        System.out.println("*************************************************");
        metodo("x");
    }
    
    public static void metodo(int nro){
        System.out.println("1");
    }
    public static void metodo(long nro){
        System.out.println("2");
    }
    public static void metodo(float nro){
        System.out.println("3");
    }
    public static void metodo(double nro){
        System.out.println("4");
    }
    public static void metodo(String t){
        System.out.println("5");
    }
    public static void metodo(char c){
        System.out.println("6");
    }
    
    public void metodo(){
        System.out.println($);
    }
    
}
