package clase05;
public class Test {}
class Test2{}
class Test3{}

interface I1{}
interface I2{}
interface I3{}

enum EstadoCivil{ SOLTERO, CASADO, VIUDO, DIVORCIADO }
enum Genero{ FEMENINO, MASCULINO, X }

//identificadores
class $hola{}
class _hola{}
class hola_2{}
class _2Hola{}
class _$Hola{}
//class 2Hola{}
//class #hola{}
//class -hola{}
//class *hola{}
//class ?hola{}

class Externa{
    private int atributo;
    
    //clase interna a nivel miembro
    private class LocalMemberClass implements I1{
    }

    public void metodo(){
        LocalMemberClass lbc=new LocalMemberClass();
        
        //Clases internas
        class LocalInnerClass implements I2{
            
        }
        
        LocalInnerClass lic=new LocalInnerClass();
        
    }
    
    public void método2(){
        LocalMemberClass lbc=new LocalMemberClass();
        //LocalInnerClass lic=new LocalInnerClass();
    }
}

interface I_Cabeza{}

class Humano{
    private String nombre;
    private class Cabeza implements I_Cabeza{
    
    }
}


class CabezaHumano implements I_Cabeza{
    
}

class CabezaPerro implements I_Cabeza{
    
}

interface I_Example{
    void metodo1();
    
    //método default java 8
    default void metodo2(){
        System.out.println("método default");
    }
}

