package repositorio;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_PersonaRepository {
    void save(Persona persona);                         //insert into personas values
    void remove(Persona persona);                       //delete from personas where 
    List<Persona>getAll();                              //select * from personas;
    default List<Persona>getByApellido(String apellido){        //select * from personas where apellido=apellido;
        if(apellido==null) return new ArrayList<Persona>();
        //List<Persona>list=new ArrayList();
        //for(Persona p:getAll()){
        //    if(p.getApellido().equalsIgnoreCase(apellido)){
        //        list.add(p);
        //    }
        //}
        //return list;
        return getAll()
                .stream()
                .filter(p->p.getApellido().equalsIgnoreCase(apellido))
                .collect(Collectors.toList());
    }
    default List<Persona>getLikeApellido(String apellido){      //select * from personas where apellido like '%apellido%';
        if(apellido==null) return new ArrayList<Persona>();
        return getAll()
                .stream()
                .filter(p->p.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Persona>getByEdad(int edad){                  //select * from personas where edad=edad;
        return getAll()
                .stream()
                .filter(p->p.getEdad()==edad)
                .collect(Collectors.toList());
    }
}
