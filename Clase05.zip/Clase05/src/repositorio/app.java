package repositorio;

public class app {
    public static void main(String[] args) {
        I_PersonaRepository pr = new PersonaRepository();
        
        pr.save(new Persona("Juan","Perez",33));
        pr.save(new Persona("Laura","Gomez",35));
        pr.save(new Persona("Joaquin","Rozales",23));
        pr.save(new Persona("Debora","Pereyra",26));
        pr.save(new Persona("Debora","Perez",26));
        pr.save(new Persona("Debora","Perez",23));
        
        //pr.getAll().forEach(System.out::println);
        //pr.getByApellido("perez").forEach(System.out::println);
        //pr.getLikeApellido("pe").forEach(System.out::println);
        pr.getByEdad(26).forEach(System.out::println);
    }
}
