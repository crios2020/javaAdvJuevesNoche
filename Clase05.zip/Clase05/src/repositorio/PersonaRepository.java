package repositorio;

import java.util.ArrayList;
import java.util.List;

public class PersonaRepository implements I_PersonaRepository {
    private List<Persona>list;
    public PersonaRepository(){
        list=new ArrayList();
    }

    @Override
    public void save(Persona persona) {
        list.add(persona);
    }

    @Override
    public void remove(Persona persona) {
        list.remove(persona);
    }

    @Override
    public List<Persona> getAll() {
        return list;
    }
    
}
