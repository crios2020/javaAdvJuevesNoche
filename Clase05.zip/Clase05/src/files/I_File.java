package files;
public interface I_File {
    void setText(String texto);
    void appendText(String texto);
    String getText();
    default void info(){
        System.out.println("Interface I_File");
    }
}
