package files;

import java.net.Socket;

public class ArchivoSocket implements I_File{

    private Socket socket;

    public ArchivoSocket(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void setText(String texto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void appendText(String texto) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getText() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
