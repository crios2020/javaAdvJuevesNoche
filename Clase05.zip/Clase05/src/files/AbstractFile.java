package files;

import java.io.File;

public abstract class AbstractFile {
    private File file;
    
    public AbstractFile(File file) {
        this.file = file;
    }

    public abstract void setText(String texto);
    public abstract void appendText(String texto);
    public abstract String getText();
    public void info(){
        System.out.println("class AbstractFile");
    }
}
