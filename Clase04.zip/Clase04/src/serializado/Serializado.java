package serializado;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Serializado {
    public static void main(String[] args) {
        File file=new File("datos.dat");
        
        //serializado
        try (ObjectOutputStream out=new ObjectOutputStream(
                        new FileOutputStream(file))) {
            out.writeObject(new Persona("Juan","Perez",33));
            out.writeObject(new Persona("Laura","Gomez",35));
            out.writeObject(new Persona("Joaquin","Rozales",23));
            out.writeObject(new Persona("Debora","Pereyra",26));
            out.writeObject(new Persona("Debora","Perez",26));
            out.writeObject(new Persona("Debora","Perez",23));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        //deserializado
        List<Persona>list=new ArrayList();
        try (ObjectInputStream in=new ObjectInputStream(
                        new FileInputStream(file))){
            while(true){
                Persona p=(Persona)in.readObject();
                //System.out.println(p);
                list.add(p);
            }
        } catch (EOFException e){ System.out.println("-- Fin del archivo! --");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
        //Api Stream
        System.out.println("*************************************************");
        
        //select * from personas
        list.forEach(System.out::println);
        
        System.out.println("*************************************************");
        //orden natural
        list.stream().sorted().forEach(System.out::println);
        
        
        //select * from personas order by apellido
        System.out.println("*************************************************");
        list
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido))
                .forEach(System.out::println);
        
        //select * from personas order by apellido desc, nombre, edad
        System.out.println("*************************************************");
        list
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido).reversed()
                        .thenComparing(Persona::getNombre)
                        .thenComparing(Persona::getEdad))
                .forEach(System.out::println);
        

        
    }
}
