package clase03;
public class Clase03 {
    public static void main(String[] args) {
        /*
        Protocolo TCP/IP
        
Server                                                                  Client
--------                                                                --------
ServerSocket ss=new ServerSocket(int port);                             Socket so=new Socket(String ip, int port)
ss.accept();
--------                                                                -------- 
OutputStream                            ---------------------->         InputStream
InputStream                             <----------------------         OutpStream
--------                                                                -------- 
ss.close();                                                             so.close()       
        
    
        BufferedWriter - BufferedReader:            buffer de bytes
        DataOutputStream - DataInputStream:         tipos primitivos
        ObjectOutputStream - ObjetctInputStream:    objetos de java
        
        */
    }
    
}
