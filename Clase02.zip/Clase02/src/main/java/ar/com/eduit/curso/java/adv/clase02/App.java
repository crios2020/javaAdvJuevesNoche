package ar.com.eduit.curso.java.adv.clase02;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class App {
    public static void main(String[] args) {
        
        Cuenta cuenta=new Cuenta();
        Cliente cliente1=new Cliente(cuenta);
        Cliente cliente2=new Cliente(cuenta);
        
        cliente1.start();
        cliente2.start();
        
        try{Thread.sleep(5000);}catch(Exception e){}
        System.out.println(cuenta.getSaldo());
        
        /*
        Que diferencias hay entre HashMap y Hashtable
        
        HashMap:
            - No se safe Thread.
            - sus métodos no son synchonized.
            - Es más veloz
        
        Hashtable:
            - se lo considera legacy.
            - Es safe Thread.
            - Sus métodos son synchronized.
            - Es lento.
        
        Collections:
            - JDK 7. provee muchas ultilidades estaticas para collecciones.
            - Puede fabricar colleciones parcialmente sincronizadas.
        
        */
        Map<String,String>map;
        
        //map=new HashMap();
        //map=new Hashtable();
        map=Collections.synchronizedMap(new HashMap<String,String>());
        
        map.put("lu", "lunes");
        map.put("ma", "martes");
        map.put("mi", "miércoles");
        map.put("ju", "jueves");
        map.put("vi", "viernes");
        System.out.println(map.get("ma"));
        
    }
}
