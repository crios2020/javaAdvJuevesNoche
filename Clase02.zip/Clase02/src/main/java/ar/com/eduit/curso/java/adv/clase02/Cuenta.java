package ar.com.eduit.curso.java.adv.clase02;
public class Cuenta {
    private float saldo=2000;
    
    public void debitar(float monto){
        System.out.println("-- iniciando operación debitar --");
        synchronized(this){     //Sincronizado parcial JDK 7 o sup
            if(saldo>=monto){
                try { Thread.sleep(2000); } catch(Exception e){} 
                saldo-=monto;
            }else{
                System.out.println("Error saldo insuficiente!");
            }
        }
        System.out.println("-- Operación debitar terminada--");
    }
    
    public synchronized float getSaldo(){
        return saldo;
    }
    
}
