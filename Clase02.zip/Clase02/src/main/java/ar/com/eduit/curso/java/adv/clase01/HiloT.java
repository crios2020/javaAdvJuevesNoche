package ar.com.eduit.curso.java.adv.clase01;
public class HiloT extends Thread{
    //cuando una clase extiende de Thread, puede ejecutar en un hilo nuevo
    
    private String nombre;

    public HiloT(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public void run(){
        //el método run es el que puede ejecutar en nuevo thread(hilo)
        
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            try{ Thread.sleep(1000); }catch(Exception e) {}
        }
        
    }
}
