package ar.com.eduit.curso.java.adv.clase02;

public class App2 {
    public static void main(String[] args) {
        Saludo saludo=new Saludo();
        
        new Empleado("Ana",false,saludo).start();
        new Empleado("Mario",false,saludo).start();
        new Empleado("Diego",false,saludo).start();
        new Empleado("Lucia",false,saludo).start();
        try { Thread.sleep(1000); } catch(Exception e){}
        new Empleado("Jefe",true,saludo).start();
        
    }
}
