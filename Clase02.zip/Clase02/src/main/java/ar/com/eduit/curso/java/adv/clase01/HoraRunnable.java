package ar.com.eduit.curso.java.adv.clase01;

import java.text.DecimalFormat;
import java.time.LocalTime;
import javax.swing.JTextField;

public class HoraRunnable implements Runnable {
    private JTextField txt;
    public HoraRunnable(JTextField txt) {
        this.txt = txt;
    }

    @Override
    public void run() {
        DecimalFormat df=new DecimalFormat("00");
        while(true){
            LocalTime lt=LocalTime.now();
            int hour=lt.getHour();
            int minute=lt.getMinute();
            int second=lt.getSecond();
            
            txt.setText(df.format(hour)+":"+df.format(minute)+":"+df.format(second));
            
            try{ Thread.sleep(1000); }catch(Exception e){}
        }
    }
    
    
    
}
