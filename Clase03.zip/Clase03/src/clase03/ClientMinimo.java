package clase03;

import java.io.InputStream;
import java.net.Socket;

public class ClientMinimo {
    public static void main(String[] args) {
        int car;
        try (   
                InputStream in=new Socket("localhost",5000).getInputStream();
        ){
            //while((car=in.read())!=-1){
            //    System.out.print((char)car);
            //}
            
            //byte[] bytes=in.readAllBytes();     //jdk 9
            for(byte b:in.readAllBytes()) System.out.print((char)b);
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println();
    }
}