package chat;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapaDirecciones {
    public static Map<String,String>getMapa(){
        Map<String,String>mapa=new LinkedHashMap();
        mapa.put("Carlos", "192.168.0.3");
        mapa.put("Ana", "192.168.0.4");
        mapa.put("Rodrigo", "192.168.0.5");
        mapa.put("Patricio", "192.168.0.3");
        return mapa;
    }
}